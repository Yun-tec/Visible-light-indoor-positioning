#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct Point {
    double x, y, z;
};

double calculateDistance(struct Point p1, struct Point p2) {
    return sqrt(pow(p2.x - p1.x, 2) + pow(p2.y - p1.y, 2) + pow(p2.z - p1.z, 2));
}

void calculateDistances(struct Point inputPoint, struct Point *leds, int numLeds) {
    double *distances = malloc(numLeds * sizeof(double));

    for (int i = 0; i < numLeds; ++i) {
        distances[i] = calculateDistance(inputPoint, leds[i]);
    }

    // 输出 LED 坐标和 Node 到各个 LED 的距离
    printf("float32_t led_positions[%d][3] = {\n", numLeds);
    for (int i = 0; i < numLeds; ++i) {
        printf("    {%.2f, %.2f},\n", leds[i].x, leds[i].y);
    }
    printf("};\n");

    printf("float32_t distances[%d] = {", numLeds);
    for (int i = 0; i < numLeds; ++i) {
        printf("%.2f", distances[i]);
        if (i < numLeds - 1) printf(", ");
    }
    printf("};\n");

//    按照LED坐标和Node到各个LED的距离输出
//    {-1.25, -1.25,  4.0774},
    printf("LED positions and distances:\n");
    for (int i = 0; i < numLeds; ++i) {
        printf("{%.2f, %.2f, %.2f},\n", leds[i].x, leds[i].y, distances[i]);
    }
    free(distances);
}

int main() {
    struct Point inputPoint = {0.7, 0.5, 0}; // Node位置
    printf("The input point is: {%.2f, %.2f, %.2f}\n", inputPoint.x, inputPoint.y, inputPoint.z);

    struct Point leds[] = { // LED坐标
            {-1.25, -1.25, 3.00},
            {-1.25, 1.55,  3.00},
            {-1.25, 1.25,  3.00},
            {1.25,  1.25,  3.00},
            {1.75,  1.35,  3.00}
    };

    int numLeds = sizeof(leds) / sizeof(leds[0]);
    calculateDistances(inputPoint, leds, numLeds);

    return 0;
}
