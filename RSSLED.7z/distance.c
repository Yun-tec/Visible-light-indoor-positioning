#include <stdio.h>
#include <math.h>

// 定义LED的结构体
typedef struct {
    float x;
    float y;
    float z;
} LED_Position;

// 初始化LED的坐标
LED_Position LED1 = {10.0, 20.0, 30.0}; // LED1的坐标为 (10, 20, 30)
LED_Position LED2 = {15.0, 25.0, 35.0}; // LED2的坐标为 (15, 25, 35)

// 距离和对应的平均AD值数组
const int distances[] = {0, 2, 7, 9, 18, 23, 26, 42, 44, 47, 51, 52, 54, 58, 59, 61, 63, 69, 70, 72, 73, 78, 79, 83, 84,
                         86, 90, 92, 93, 96, 97, 101, 102, 104, 106, 107, 109, 111, 114, 116, 118, 119, 121, 122, 125,
                         127, 128, 133, 134, 138, 140, 142, 147, 149, 150, 152, 155, 156, 158, 160, 163, 167, 168, 169,
                         172, 173, 176, 180, 181, 184, 185, 186, 188, 190
}; // 单位：mm
const float average_ad_values[] = {463.30, 554.00, 567.00, 570.00, 580.00, 598.50, 610.00, 611.00, 621.75, 630.00,
                                   641.50, 643.00, 645.00, 658.67, 659.00, 667.00, 675.33, 683.00, 706.89, 739.00,
                                   743.00, 757.00, 777.00, 780.00, 785.00, 790.67, 794.00, 800.00, 813.00, 822.00,
                                   825.50, 833.33, 844.00, 852.00, 848.00, 862.00, 867.00, 875.67, 894.00, 904.00,
                                   916.00, 919.00, 927.00, 937.00, 949.00, 963.00, 981.00, 1006.00, 1058.00, 1122.00,
                                   1199.00, 1271.00, 1431.00, 1635.00, 1712.00, 1775.00, 1914.00, 2167.67, 2310.00,
                                   2463.00, 2632.50, 2695.50, 2713.00, 2738.00, 2764.00, 2783.00, 2820.33, 2848.00,
                                   2857.00, 2878.67, 2900.00, 2910.00, 2936.00, 2957.00
}; // 对应的平均AD值



// 计算接收端到LED的距离
float calculate_distance_to_LED(LED_Position *ptr, LED_Position *receiver) {
    float dx = ptr->x - receiver->x;
    float dy = ptr->y - receiver->y;
    float dz = ptr->z - receiver->z;
    return sqrt(dx * dx + dy * dy + dz * dz);
}

int findClosest(float target, const float arr[], int n) {
    // 二分搜索查找最接近的元素索引
    int left = 0, right = n - 1;
    // 如果目标值小于数组的第一个元素，返回第一个元素的索引
    if (target <= arr[0]) return 0;
    // 如果目标值大于数组的最后一个元素，返回最后一个元素的索引
    if (target >= arr[n - 1]) return n - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;

        // 如果目标值在当前元素和下一个元素之间，返回当前元素的索引
        if (arr[mid] <= target && target <= arr[mid + 1]) {
            return (target - arr[mid] >= arr[mid + 1] - target) ? (mid + 1) : mid;
        }

        // 如果目标值小于当前元素，向左搜索
        if (arr[mid] > target) {
            right = mid - 1;
        }
            // 否则，向右搜索
        else {
            left = mid + 1;
        }
    }
    // 这里的返回语句永远不会执行，只是为了避免编译器报错
    return -1;
}
int main(void)
{
    // 测试二分搜索
    float target = 2000.0;
    int index = findClosest(target, average_ad_values, sizeof(average_ad_values) / sizeof(average_ad_values[0]));
    printf("The closest element to %.2f is %.2f at index %d.\n", target, average_ad_values[index], index);
//    对应距离为
    printf("The corresponding distance is %d mm.\n", distances[index]);


    // 在代码中使用LED的坐标
    float distance_to_LED1 = calculate_distance_to_LED(&LED1, &LED2);


    return 0;

}


