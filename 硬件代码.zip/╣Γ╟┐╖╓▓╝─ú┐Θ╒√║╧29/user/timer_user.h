#ifndef __TIMER_USER_H_
#define __TIMER_USER_H_
#include "timer.h"

void tim_user_init(void);

#endif//__TIMER_USER_H_
