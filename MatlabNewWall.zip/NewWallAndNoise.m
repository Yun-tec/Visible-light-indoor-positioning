
%%
theta = 70;
% semi-angle at half power
ml=-log10(2)/log10(cosd(theta));
%Lambertian order of emission
P_LED=20;
%transmitted optical power by individual LED单个LED的传输光功率
nLED=60;
% number of LED array nLED*nLED LED阵列个数nLED*nLED
P_total=nLED*nLED*P_LED;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%P_total_dBm=10*log10(P_total);
%P_total_dBm_noise=awgn(P_total_dBm,20);
%P_total=10^(P_total_dBm_noise/10);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Total transmitted power总传输功率
Adet=1e-4;
%detector physical area of a PD

Ts=1;
%gain of an optical filter; ignore if no filter is used
index=1.5;
%refractive index of a lens at a PD; ignore if no lens is used
FOV=70;
%FOV of a receiver
G_Con=(index^2)/(sind(FOV).^2);
%gain of an optical concentrator; ignore if no lens is used
%%
h=2.15;
%the distance between source and receiver plane
lx=5; ly=5; lz=2.15;
% room dimension in meter
[XT,YT,ZT]=meshgrid([-lx/4 0 lx/4],[-ly/4 0 ly/4],lz/2);
% position of Transmitter (LED);
Nx=lx*5+1; Ny=ly*5+1; Nz=round(lz*5)+1;
% number of grid in each surface
dA=lz*ly/(Ny*Nz);
% calculation grid area
x=linspace(-lx/2,lx/2,Nx);
y=linspace(-ly/2,ly/2,Ny);
z=linspace(-lz/2,lz/2,Nz);
[XR,YR,ZR]=meshgrid(x,y, -lz/2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A1_wall=GetWallRec(1,1,P_total);
A2_wall=GetWallRec(2,1,P_total);
A3_wall=fliplr(A1_wall);
A4_wall=GetWallRec(1,2,P_total);
A5_wall=GetWallRec(2,2,P_total);
A6_wall=fliplr(A4_wall);
A7_wall=flipud(A1_wall);
A8_wall=flipud(A2_wall);
A9_wall=fliplr(A7_wall);
WallRec=A1_wall+A2_wall+A3_wall+A4_wall+A5_wall+A6_wall+A7_wall+A8_wall+A9_wall;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
D1=sqrt((XR-XT(1,1)).^2+(YR-YT(1,1)).^2+h^2);
% distance vector from source 1距离源1的距离矢量
cosphi_A1=h./D1;
% angle vector
receiver_angle_1=acosd(cosphi_A1);
D2=sqrt((XR-XT(1,2)).^2+(YR-YT(1,2)).^2+h^2);
cosphi_A2=h./D2;
% angle vector
receiver_angle_2=acosd(cosphi_A2);
D3=sqrt((XR-XT(2,2)).^2+(YR-YT(2,2)).^2+h^2);
cosphi_A5=h./D3;
% angle vector
receiver_angle_5=acosd(cosphi_A5);
D4=sqrt((XR-XT(2,1)).^2+(YR-YT(2,1)).^2+h^2);
cosphi_A4=h./D4;
% angle vector
receiver_angle_4=acosd(cosphi_A4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
H_A1=(ml+1)*Adet.*cosphi_A1.^(ml+1)./(2*pi.*D1.^2);
H_A2=(ml+1)*Adet.*cosphi_A2.^(ml+1)./(2*pi.*D2.^2);
H_A5=(ml+1)*Adet.*cosphi_A5.^(ml+1)./(2*pi.*D3.^2);
H_A4=(ml+1)*Adet.*cosphi_A4.^(ml+1)./(2*pi.*D4.^2);
% channel DC gain for source 1源1的通道直流增益
P_rec_A1=P_total.*H_A1.*Ts.*G_Con+A1_wall;
P_rec_A2=P_total.*H_A2.*Ts.*G_Con+A2_wall;
P_rec_A4=P_total.*H_A4.*Ts.*G_Con+A4_wall;
P_rec_A5=P_total.*H_A5.*Ts.*G_Con+A5_wall;
% received power from source 1;接收源1的功率;
P_rec_A1(find(abs(receiver_angle_1)>FOV))=0;
P_rec_A2(find(abs(receiver_angle_2)>FOV))=0;
P_rec_A4(find(abs(receiver_angle_4)>FOV))=0;
P_rec_A5(find(abs(receiver_angle_5)>FOV))=0;
% if the anlge of arrival is greater than FOV, no current is generated at the photodiode.
%如果到达角大于视场，光电二极管不产生电流。 
P_rec_A3=fliplr(P_rec_A1);
P_rec_A6=fliplr(P_rec_A4);
% received power from source 2, due to symmetry no need separate calculations
%从源2接收能量，由于对称性，不需要单独计算 
P_rec_A7=flipud(P_rec_A1);
P_rec_A8=flipud(P_rec_A2);
P_rec_A9=flipud(P_rec_A3);
P_rec_total=P_rec_A1+P_rec_A2+P_rec_A3+P_rec_A4+P_rec_A5+P_rec_A6+P_rec_A7+P_rec_A8+P_rec_A9;
%%
allpos=zeros(26,26);

for ii=1:26
 for jj=1:26
    row=(2.5+y(jj))/0.2+1;
    col=(2.5+x(ii))/0.2+1;
    
    P_rec1=P_rec_A1(round(row),round(col));
    P_rec2=P_rec_A2(round(row),round(col));
    P_rec3=P_rec_A3(round(row),round(col));
    P_rec4=P_rec_A4(round(row),round(col));
    P_rec5=P_rec_A5(round(row),round(col));
    P_rec6=P_rec_A6(round(row),round(col));
    P_rec7=P_rec_A7(round(row),round(col));
    P_rec8=P_rec_A8(round(row),round(col));
    P_rec9=P_rec_A9(round(row),round(col));
    
    dis1=CalculateD(P_rec1);
    dis2=CalculateD(P_rec2);
    dis3=CalculateD(P_rec3);
    dis4=CalculateD(P_rec4);
    dis5=CalculateD(P_rec5);
    dis6=CalculateD(P_rec6);
    dis7=CalculateD(P_rec7);
    dis8=CalculateD(P_rec8);
    dis9=CalculateD(P_rec9);
    
    Ds=[dis1,dis2,dis3,dis4,dis5,dis6,dis7,dis8,dis9];
    pos=Calculate_position(Ds);
    
    %测误差，保留4位小数，单位米
    distance=roundn(sqrt((x(ii)-pos(1)).^2+(y(jj)-pos(2)).^2),-4);
    %allpos的行对应y轴，列对应x轴，如allpos(a,b)对应坐标[0.2*(b-1)-2.5,0.2*(a-1)-2.5]
    allpos(ii,jj)=distance;
 end
end

surfc(x,y,allpos);
% contour(x,y,P_rec_dBm);hold on
% mesh(x,y,P_rec_dBm);