function d = CalculateD(P_rec)
%UNTITLED7 此处显示有关此函数的摘要
%   此处显示详细说明
theta=70;%半功率点半角
m=-log10(2)/log10(cosd(theta));%朗伯发射系数
P_LED=20;%单个LED的发射功率mW
nLED=60;%LED阵列 nLED*nLED
P_total=nLED*nLED*P_LED;%总发射功率
Adet=1e-4;%PD接收面面积
Ts=1;%光滤波器增益，未用可忽略
index=1.5;%PD用透镜的折射率，未用可忽略
FOV=70;%接收视场角
G_Con=(index^2)/(sind(FOV).^2);%集光器增益
h=2.15;%源与接收平面的距离
%推算公式
value1=(m+1)*P_total*Adet*h^(m+1)*Ts*G_Con;
value2=1/(m+3);
d=(value1/(2*pi.*P_rec))^value2;
end

