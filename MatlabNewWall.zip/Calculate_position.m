%% 前言介绍
%计算接收器位置。已知9个LED灯的分布坐标为
% x1（1.25，1.25）x2（2.5，1.25） x3 （3.75，1.25） x4（1.25，2.5） x5（2.5,2.5）
% x6（3.75,2.5） x7（1.25，3.75） x8（2.5,3.75） x9（3.75,3.75） 式子化简成：AX=B
% A为常量，根据LED灯的坐标而定
%A=[1.25 0;2.5 0;0 1.25;1.25 1.25;2.5 1.25;0 2.5;1.25 2.5;2.5 2.5]
%%
% 定义接收器与发射器之间的距离为d
function X0=Calculate_position(d)
% 为测试方便，此处随机生成了（2,3）的距离
%function X0=Calculate_position(d) 定义LED的坐标，（x，y）
x=zeros(1,9);
x=[-1.25,0,1.25,-1.25,0,1.25,-1.25,0,1.25];
y=zeros(1,9);
y=[-1.25,-1.25,-1.25,0,0,0,1.25,1.25,1.25];

%% 矩阵A的赋值，for循环遍历
% 定义A的左右两列
A_LEFT=zeros(1,8);
A_RIGHT=zeros(1,8);
% A_LEFT赋值
for i=1:8
    A_LEFT(i)=x(i+1)-x(1);
end
% A_RIGHT赋值
for i=1:8
    A_RIGHT(i)=y(i+1)-y(1);
end
% 为A矩阵赋值
A=zeros(8,2);
for i=1:16
    if (i<=8)
        A(i)=A_LEFT(i);
    else
        A(i)=A_RIGHT(i-8);
    end
end

%%
%  矩阵B的赋值，由Bcell组成 为Bcell赋值
Bcell=zeros(1,8);
for i=1:8
    Bcell(i)=(  ( d(1)^2 - d(i+1)^2 )+ ( x(i+1)^2 + y(i+1)^2 )- ( x(1)^2 + y(1)^2 ));
end
% 为矩阵B赋值
B=zeros(8,1);
for i=1:8
    B(i)=(1/2)*Bcell(i);
end
%%
% 解最终坐标 最优解通过最小化S=||B-AX0||2 2得到 X0=[x_positon,y_positon]'
%syms x_position
%syms y_position
%X0=[x_positon,y_positon]';
X0=inv((A'*A))*A'*B;
end


